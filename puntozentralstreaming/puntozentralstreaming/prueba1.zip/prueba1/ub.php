<!DOCTYPE html>
<html>
<head>
    <link  rel="icon" href="logos/logocen.png" type="image/png"/>
<title>ALERTA</title>
<meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="style.css">
<style>
html,body{
    height:100%;
  width: 100%;
  font-family: 'Josefin Sans', sans-serif;

}
* {
  box-sizing: border-box;
}
.img{
  display:block;
margin:auto;
  background-size:cover;
}
</style>
<body>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<img src="logos/alerta.png" class="img">
<br>
  <label> <b><h1>¿NO ESTAS REGISTRADO AUN?</h1></b> </label>
  <br>
</body>
</html>
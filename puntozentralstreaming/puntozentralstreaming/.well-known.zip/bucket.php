 	<?php 
	include('conexion.php');
	include('vendor/autoload.php');

	// AWS Info
	$bucketName = 'interfaznva';
	$IAM_KEY = 'AKIAZEW65VBVJHLCGDIG';
	$IAM_SECRET = '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';
	$centro = 'puntozentralstreaming';
$nombre='Sofia Ruiz'; //nombre de el centro, no es URL
$color='red'; /color de tablas, puede ser: black, red, orange, purple, yellow, etc
$color2='red'; // color al apretar botón, si es en hexadecimal lleva #
cel='3331851156' /sin lada
$fb='sofisrv'; /sofisrv
$insta='sofisrv'; sofisrv
